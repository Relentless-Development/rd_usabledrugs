['xpills'] = {
    label = 'X Pills',
    weight = 100,
    stack = true,
    close = true,
    description = 'Unknown high-powered stimulant.',
    client = {
        export = 'rd_usabledrugs.useItem'
    },
},

['bottleofpercs'] = {
    label = 'Bottle of Percs',
    weight = 150,
    stack = true,
    close = true,
    description = 'Pain relief and slight body high.',
    client = {
        export = 'rd_usabledrugs.useItem'
    },
},

['xanaxbars'] = {
    label = 'Xanax Bars',
    weight = 100,
    stack = true,
    close = true,
    description = 'Chill out with this anti-anxiety pill.',
    client = {
        export = 'rd_usabledrugs.useItem'
    },
},

['hydrocodone'] = {
    label = 'Hydrocodone',
    weight = 120,
    stack = true,
    close = true,
    description = 'Potent opioid for serious pain.',
    client = {
        export = 'rd_usabledrugs.useItem'
    },
},
