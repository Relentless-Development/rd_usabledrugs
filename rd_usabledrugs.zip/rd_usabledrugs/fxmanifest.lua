fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'Relentless Development'
description 'Usable Pills'
version '1.0.0'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

client_export 'useItem'

dependency 'ox_lib'
