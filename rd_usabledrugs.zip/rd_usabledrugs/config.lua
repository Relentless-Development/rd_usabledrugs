Config = {}

Config.Drugs = {
    xpills = {
        label = "X Pills",
        animation = {dict = "mp_suicide", name = "pill"},
        effect = function()
            local playerPed = PlayerPedId()

            SetPedArmour(playerPed, 100)
            SetRunSprintMultiplierForPlayer(PlayerId(), 1.5)

            local staminaThread = true
            CreateThread(function()
                local timer = 15
                while timer > 0 and staminaThread do
                    RestorePlayerStamina(PlayerId(), 1.0)
                    Wait(1000)
                    timer = timer - 1
                end
                SetRunSprintMultiplierForPlayer(PlayerId(), 1.0)
            end)

            Wait(15000)
            staminaThread = false
        end
    },

    bottleofpercs = {
        label = "Bottle of Percs",
        animation = {dict = "mp_player_inteat@burger", name = "mp_player_int_eat_burger"},
        effect = function()
            local ped = PlayerPedId()
            local health = GetEntityHealth(ped)
            SetEntityHealth(ped, math.min(health + 30, 200))
            SetPedMoveRateOverride(ped, 1.1)
            Wait(15000)
            SetPedMoveRateOverride(ped, 1.0)
        end
    },

    xanaxbars = {
        label = "Xanax Bars",
        animation = {dict = "amb@world_human_drinking@coffee@male@base", name = "base"},
        effect = function()
            local ped = PlayerPedId()
            SetPedMoveRateOverride(ped, 0.8)
            Wait(15000)
            SetPedMoveRateOverride(ped, 1.0)
        end
    },

    hydrocodone = {
        label = "Hydrocodone",
        animation = {dict = "mp_suicide", name = "pill"},
        effect = function()
            local ped = PlayerPedId()
            local health = GetEntityHealth(ped)
            SetEntityHealth(ped, math.min(health + 50, 200))
        end
    },
}
