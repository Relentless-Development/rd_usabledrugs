local effectsActive = {}

-- Load animation dictionary
local function LoadAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        RequestAnimDict(dict)
        Wait(10)
    end
end

-- Load movement clipset
local function LoadMovementClipset(clipset)
    RequestAnimSet(clipset)
    while not HasAnimSetLoaded(clipset) do
        Wait(0)
    end
end

-- Notification
local function safeNotify(data)
    if not data.title or not data.description then return end
    exports.ox_lib:notify(data)
end

-- Drug effect: X Pills
local function applyXpillsEffect()
    local ped = PlayerPedId()
    local effectDuration = 15 -- seconds
    local playerId = PlayerId()

    -- Full armor
    SetPedArmour(ped, 100)

    -- Load and apply clipset
    local clipset = "move_m@quick"
    LoadMovementClipset(clipset)
    SetPedMovementClipset(ped, clipset, 1.0)

    -- Apply sprint & swim multiplier for speed boost
    SetRunSprintMultiplierForPlayer(playerId, 1.49)
    SetSwimMultiplierForPlayer(playerId, 1.49)

    -- Apply stamina regen & keep applying speed boost to prevent reset
    effectsActive["xpills"] = true
    CreateThread(function()
        local time = effectDuration
        while time > 0 and effectsActive["xpills"] do
            RestorePlayerStamina(playerId, 1.0)
            SetRunSprintMultiplierForPlayer(playerId, 1.49)
            SetSwimMultiplierForPlayer(playerId, 1.49)
            Wait(1000)
            time = time - 1
        end
        -- Reset to normal
        ResetPedMovementClipset(ped, 1.0)
        SetRunSprintMultiplierForPlayer(playerId, 1.0)
        SetSwimMultiplierForPlayer(playerId, 1.0)
        effectsActive["xpills"] = nil
    end)
end

-- Drug effect: Percs
local function applyBottleOfPercsEffect()
    local ped = PlayerPedId()
    SetEntityHealth(ped, math.min(GetEntityHealth(ped) + 30, 200))
    SetPedMoveRateOverride(ped, 1.1)

    effectsActive["bottleofpercs"] = true
    CreateThread(function()
        Wait(15000)
        SetPedMoveRateOverride(ped, 1.0)
        effectsActive["bottleofpercs"] = nil
    end)
end

-- Xanax
local function applyXanaxBarsEffect()
    SetPedMoveRateOverride(PlayerPedId(), 0.8)

    effectsActive["xanaxbars"] = true
    CreateThread(function()
        Wait(15000)
        SetPedMoveRateOverride(PlayerPedId(), 1.0)
        effectsActive["xanaxbars"] = nil
    end)
end

-- Hydro
local function applyHydrocodoneEffect()
    SetEntityHealth(PlayerPedId(), math.min(GetEntityHealth(PlayerPedId()) + 50, 200))
end

-- Use drug item
RegisterNetEvent('rd_usabledrugs:useDrugEffect', function(itemName)
    local ped = PlayerPedId()
    local animDict = "mp_suicide"
    local animName = "pill"

    LoadAnimDict(animDict)
    TaskPlayAnim(ped, animDict, animName, 8.0, -8.0, 2000, 49, 0, false, false, false)
    Wait(2000)
    ClearPedTasks(ped)

    -- Remove item first
    TriggerServerEvent('rd_usabledrugs:removeItem', itemName)

    -- Notify
    safeNotify({
        title = 'Drug Used',
        description = 'You used ' .. itemName,
        type = 'inform'
    })

    -- Apply correct effect
    if itemName == "xpills" then
        applyXpillsEffect()
    elseif itemName == "bottleofpercs" then
        applyBottleOfPercsEffect()
    elseif itemName == "xanaxbars" then
        applyXanaxBarsEffect()
    elseif itemName == "hydrocodone" then
        applyHydrocodoneEffect()
    end
end)

-- ox_inventory export
exports('useItem', function(item)
    TriggerEvent('rd_usabledrugs:useDrugEffect', item.name)
end)
