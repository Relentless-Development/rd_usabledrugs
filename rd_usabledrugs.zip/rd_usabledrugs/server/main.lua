ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterNetEvent('rd_usabledrugs:removeItem')
AddEventHandler('rd_usabledrugs:removeItem', function(itemName)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer then
        xPlayer.removeInventoryItem(itemName, 1)
    end
end)
